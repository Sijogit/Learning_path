// w.a.p to check a person is eligible for voting or not using if-else statement.
x=17
if(x>=18){
    console.log('eligible for voting');
     
}
else{
    console.log('not eligible for voting');
}
// w.a.p  to  check whethera given number is positive or negative
x = -10
if(x>=0){
    console.log('given number is positive');
} 
else{
    console.log('given number is negative');
}
// w.a.p. print the greatest amoung 2 numbers
x=50
y=60
if(x>y){
    console.log('greater');
}
else if(x==y){
    console.log('equal');
}
else{
    console.log('lesser');
}