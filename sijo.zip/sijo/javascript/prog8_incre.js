inc = 10
console.log(`initial value of inc`, inc);
console.log(`incrementing inc by 1`, ++inc);
console.log(`incrementing inc by 1`, inc++);
console.log(`incrementing inc by 1`, inc);