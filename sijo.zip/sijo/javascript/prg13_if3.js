// w.a.p to print the greatest number amoung 2 numbers
num1=20
num2=20
if(num1>num2){
    console.log(`${num1} is greater than ${num2}`);
}
else if(num1==num2){
    console.log(`given numbers are equal`);
}
else{
    console.log(`${num2} is greater than ${num1}`);
}