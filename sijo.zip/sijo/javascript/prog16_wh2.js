// w.a.p to print all even numbers from 1 to 50
i=1
while(i<=50){
    if(i%2==0){
        console.log(i);
    }
    i++
}
// w.a.p to print all odd numbers from 1 to 50
i=1
while(i<=50){
    if(i%2!==0){
        console.log(i);
    }i++
}

