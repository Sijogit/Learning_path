//  w.a.p to print javascript 3 times
i=1
while(i<=3){
   console.log('javascript');
   i++
}
// w.a.p to print 1 to 5 using while loop
i=1
while(i<=5){
    console.log(`${i}`);
    i++
}
// w.a.p to print from 5 to 1 using while loop
i=5
while(i>=1){
    console.log(`${i}`);
    i--
}
