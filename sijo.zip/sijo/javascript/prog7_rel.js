num1 = 10
num2 = '10'
console.log(`the given two numbers are equal: ${num1==num2}`);
console.log(`the given two numbers are equal: ${num1===num2}`);