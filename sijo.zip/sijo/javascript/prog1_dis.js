console.log(typeof("Hello World!"));
console.log(typeof(5));
console.log('my flat number is: +7');
console.log('my flat number is:' ,7);
console.log(7 + 7);
console.log(7+'kooi');