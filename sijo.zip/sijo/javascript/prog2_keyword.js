const x=10
console.log(x)
var y=10
y=30
console.log(y);