x=10
y=20
console.log(`the sum of ${x} and ${y} is ${x+y} `);
console.log(`the difference of ${x} and ${y} is ${x-y}`);
console.log(`the difference of ${y} and ${x} is ${y-x}`);
console.log(`the product of ${x} and ${y} is ${x*y}`);
console.log(`the division of ${x} and ${y} is ${x/y}`);
console.log(`the power of ${x} and ${y} is ${x**y}`);
console.log(`the modulus of ${x} and ${y} is ${x%y}`);