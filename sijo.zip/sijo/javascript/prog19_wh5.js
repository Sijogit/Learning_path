// w.a.p to print the factorial of a given number(1*2*3*4)
i =1
num  =4
fact =1
while(i<=num){
    fact=fact*i
    i++
} console.log(fact);