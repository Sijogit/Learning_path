company = ' luminar'
location = 'kakkanad'
// concatenation
console.log('company name is'  + company + 'and it is located in' + location);
// template literals
console.log(`company name is ${company} and it is located in ${location}`); 